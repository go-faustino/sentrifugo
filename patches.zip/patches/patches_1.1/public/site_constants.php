<?php
           defined('DATEFORMAT_PHP') || define('DATEFORMAT_PHP','Y/m/d');
           defined('DATEFORMAT_MYSQL') || define('DATEFORMAT_MYSQL','%Y/%m/%d');
           defined('DATEFORMAT_JS') || define('DATEFORMAT_JS','yy/mm/dd');
           defined('DATE_DESCRIPTION') || define('DATE_DESCRIPTION','Four digit year, month and day with slashes');
           defined('TIME_FORMAT') || define('TIME_FORMAT','h:i A');   
           defined('TIMEZONE_OFFSET') || define('TIMEZONE_OFFSET','+05:30');   
           defined('CURRENCY_FORMAT') || define('CURRENCY_FORMAT','USD US Dollars');
           defined('PASSWORD_FORMAT') || define('PASSWORD_FORMAT','Alphanumeric');
        ?>